app.component('AddItemMenu', {
    props:{
        newName:String,
        newDescription:String,
        Priority:
    },

})