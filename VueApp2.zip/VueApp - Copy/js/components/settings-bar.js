app.component('SettingsBar', {

    data: function() {
        return {}
    },
    props: {

    },

    methods: {
    },
    emits: ['sort'],


})